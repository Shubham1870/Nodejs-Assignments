
const fs = require('fs/promises')


const myFileWriter = async (fileName, fileContent) => {
	// write code here
    fileName=process.argv[2]
    fileContent=process.argv[3]
    console.log(process.argv)
    console.log(fileName+" "+fileContent)
}
myFileWriter()

const myFileReader = async (fileName) => {
	// write code here
    fileName="shubham yadav"
    console.log(fileName)
	// dont chnage function name
}
myFileReader()


const myFileUpdater = async (fileName, fileContent) => {
	// write code here
    fileName="shubham"
    fileContent="yadav"
    console.log(fileName+" "+fileContent)
	// dont chnage function name
}
myFileUpdater()

const myFileDeleter = async (fileName) => {
	// write code here
	// dont chnage function name
    fileName="shubham yadav"
  console.log(fileName.slice(8,13))
    
}
myFileDeleter()




module.exports = { myFileWriter, myFileUpdater, myFileReader, myFileDeleter }